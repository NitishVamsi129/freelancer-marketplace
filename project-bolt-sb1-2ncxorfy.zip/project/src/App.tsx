import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Layout from './components/layout/Layout';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import FreelancerSearchPage from './pages/FreelancerSearchPage';
import FreelancerProfilePage from './pages/FreelancerProfilePage';
import ClientDashboardPage from './pages/ClientDashboardPage';
import FreelancerDashboardPage from './pages/FreelancerDashboardPage';
import JobPostPage from './pages/JobPostPage';
import JobDetailsPage from './pages/JobDetailsPage';
import MessagesPage from './pages/MessagesPage';
import NotFoundPage from './pages/NotFoundPage';
import ProtectedRoute from './components/auth/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="login" element={<LoginPage />} />
            <Route path="signup" element={<SignupPage />} />
            <Route path="freelancers" element={<FreelancerSearchPage />} />
            <Route path="freelancers/:id" element={<FreelancerProfilePage />} />
            <Route path="jobs/:id" element={<JobDetailsPage />} />
            <Route path="messages" element={
              <ProtectedRoute>
                <MessagesPage />
              </ProtectedRoute>
            } />
            <Route path="post-job" element={
              <ProtectedRoute>
                <JobPostPage />
              </ProtectedRoute>
            } />
            <Route path="client-dashboard" element={
              <ProtectedRoute>
                <ClientDashboardPage />
              </ProtectedRoute>
            } />
            <Route path="freelancer-dashboard" element={
              <ProtectedRoute>
                <FreelancerDashboardPage />
              </ProtectedRoute>
            } />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;