import React from 'react';
import { Link } from 'react-router-dom';
import { Briefcase as BriefcaseBusiness, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="mb-8 md:mb-0">
            <Link to="/" className="flex items-center">
              <BriefcaseBusiness className="h-8 w-8 text-white" />
              <span className="ml-2 text-xl font-bold">FreelanceHub</span>
            </Link>
            <p className="mt-2 text-sm text-gray-300">
              Connect with the perfect freelancer for your project. Quality work, delivered on time.
            </p>
            <div className="mt-4 flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* For Freelancers */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">For Freelancers</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/signup" className="text-gray-300 hover:text-white text-sm">
                  Create Account
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Find Work
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Success Stories
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Resources
                </a>
              </li>
            </ul>
          </div>

          {/* For Clients */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">For Clients</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/post-job" className="text-gray-300 hover:text-white text-sm">
                  Post a Job
                </Link>
              </li>
              <li>
                <Link to="/freelancers" className="text-gray-300 hover:text-white text-sm">
                  Find Freelancers
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Enterprise Solutions
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Success Stories
                </a>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">Resources</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Community
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white text-sm">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-700 pt-8 md:flex md:items-center md:justify-between">
          <p className="text-sm text-gray-400">
            &copy; {new Date().getFullYear()} FreelanceHub. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;