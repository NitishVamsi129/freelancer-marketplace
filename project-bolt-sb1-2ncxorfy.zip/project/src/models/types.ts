// Core data types for the freelancer marketplace

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'client' | 'freelancer';
  avatar?: string;
  bio?: string;
  location?: string;
  joinedDate: string;
}

export interface Freelancer extends User {
  skills: string[];
  hourlyRate: number;
  title: string;
  about: string;
  experience: number; // in years
  languages: string[];
  education?: Education[];
  workHistory?: WorkHistory[];
  portfolio?: PortfolioItem[];
  completedJobs: number;
  rating: number;
}

export interface Client extends User {
  company?: string;
  industry?: string;
  website?: string;
  totalSpent?: number;
  postedJobs?: number;
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startDate: string;
  endDate?: string;
  current: boolean;
  description?: string;
}

export interface WorkHistory {
  id: string;
  company: string;
  title: string;
  startDate: string;
  endDate?: string;
  current: boolean;
  description: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  description: string;
  image: string;
  link?: string;
  tags: string[];
}

export interface Job {
  id: string;
  title: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  clientId: string;
  client: Client;
  budget: {
    min: number;
    max: number;
  };
  skills: string[];
  category: string;
  experience: 'Entry' | 'Intermediate' | 'Expert';
  duration: string;
  proposals: number;
  status: 'open' | 'in-progress' | 'completed' | 'cancelled';
}

export interface Proposal {
  id: string;
  jobId: string;
  freelancerId: string;
  coverLetter: string;
  bidAmount: number;
  estimatedDuration: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  createdAt: string;
  read: boolean;
}

export interface Conversation {
  id: string;
  participants: string[];
  lastMessage?: Message;
  unreadCount: number;
}

export interface Review {
  id: string;
  jobId: string;
  clientId: string;
  freelancerId: string;
  rating: number;
  comment: string;
  createdAt: string;
}