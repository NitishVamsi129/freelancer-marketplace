import { Freelancer, Job, Client, Conversation, Message, Proposal, Review } from '../models/types';
import { format, subDays, subMonths, subYears, addDays } from 'date-fns';

// Mock Clients
export const mockClients: Client[] = [
  {
    id: 'user1',
    name: 'John Client',
    email: 'john@example.com',
    role: 'client',
    avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150',
    company: 'TechStart Inc.',
    industry: 'Software Development',
    website: 'https://techstart.example.com',
    totalSpent: 15000,
    postedJobs: 8,
    joinedDate: format(subMonths(new Date(), 6), 'yyyy-MM-dd'),
    location: 'San Francisco, CA'
  },
  {
    id: 'user3',
    name: 'Emma Watson',
    email: 'emma@example.com',
    role: 'client',
    avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150',
    company: 'Design Masters',
    industry: 'Graphic Design',
    totalSpent: 8000,
    postedJobs: 5,
    joinedDate: format(subMonths(new Date(), 3), 'yyyy-MM-dd'),
    location: 'New York, NY'
  }
];

// Mock Freelancers
export const mockFreelancers: Freelancer[] = [
  {
    id: 'user2',
    name: 'Sarah Freelancer',
    email: 'sarah@example.com',
    role: 'freelancer',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150',
    skills: ['JavaScript', 'React', 'Node.js', 'TypeScript', 'MongoDB'],
    hourlyRate: 45,
    title: 'Full Stack Developer',
    about: 'Experienced web developer with 5+ years building modern web applications. Specialized in React and Node.js.',
    experience: 5,
    languages: ['English', 'Spanish'],
    completedJobs: 42,
    rating: 4.9,
    joinedDate: format(subYears(new Date(), 2), 'yyyy-MM-dd'),
    location: 'Austin, TX',
    education: [
      {
        id: 'edu1',
        institution: 'University of Texas',
        degree: 'Bachelor of Science',
        fieldOfStudy: 'Computer Science',
        startDate: '2015-09-01',
        endDate: '2019-05-15',
        current: false,
        description: 'GPA 3.8, Dean\'s List'
      }
    ],
    workHistory: [
      {
        id: 'work1',
        company: 'TechCorp',
        title: 'Junior Developer',
        startDate: '2019-06-01',
        endDate: '2021-08-15',
        current: false,
        description: 'Built and maintained web applications using React.js and Node.js'
      },
      {
        id: 'work2',
        company: 'Freelance',
        title: 'Full Stack Developer',
        startDate: '2021-09-01',
        endDate: undefined,
        current: true,
        description: 'Work with clients to develop custom web solutions'
      }
    ],
    portfolio: [
      {
        id: 'port1',
        title: 'E-commerce Platform',
        description: 'A full-featured online store with payment processing and inventory management',
        image: 'https://images.pexels.com/photos/6969754/pexels-photo-6969754.jpeg?auto=compress&cs=tinysrgb&w=600',
        link: 'https://example.com/ecommerce',
        tags: ['React', 'Node.js', 'MongoDB', 'Stripe']
      },
      {
        id: 'port2',
        title: 'Task Management App',
        description: 'A collaborative task management tool for remote teams',
        image: 'https://images.pexels.com/photos/5313361/pexels-photo-5313361.jpeg?auto=compress&cs=tinysrgb&w=600',
        link: 'https://example.com/taskapp',
        tags: ['React', 'Firebase', 'Material UI']
      }
    ]
  },
  {
    id: 'user4',
    name: 'Michael Chen',
    email: 'michael@example.com',
    role: 'freelancer',
    avatar: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150',
    skills: ['UI/UX Design', 'Figma', 'Adobe XD', 'Sketch', 'Prototyping'],
    hourlyRate: 55,
    title: 'UI/UX Designer',
    about: 'Passionate designer creating beautiful and functional user interfaces. I specialize in user-centered design processes.',
    experience: 7,
    languages: ['English', 'Mandarin'],
    completedJobs: 64,
    rating: 4.8,
    joinedDate: format(subYears(new Date(), 3), 'yyyy-MM-dd'),
    location: 'Seattle, WA',
    portfolio: [
      {
        id: 'port3',
        title: 'Financial App Redesign',
        description: 'Complete UI overhaul for a fintech application',
        image: 'https://images.pexels.com/photos/6804600/pexels-photo-6804600.jpeg?auto=compress&cs=tinysrgb&w=600',
        tags: ['UI/UX', 'Figma', 'Fintech']
      }
    ]
  },
  {
    id: 'user5',
    name: 'Jessica Miller',
    email: 'jessica@example.com',
    role: 'freelancer',
    avatar: 'https://images.pexels.com/photos/1181695/pexels-photo-1181695.jpeg?auto=compress&cs=tinysrgb&w=150',
    skills: ['Content Writing', 'SEO', 'Blog Posts', 'Technical Writing', 'Copywriting'],
    hourlyRate: 35,
    title: 'Content Writer & SEO Specialist',
    about: 'Professional writer with a knack for creating engaging, SEO-optimized content for websites, blogs, and marketing materials.',
    experience: 4,
    languages: ['English'],
    completedJobs: 87,
    rating: 4.7,
    joinedDate: format(subYears(new Date(), 1), 'yyyy-MM-dd'),
    location: 'Chicago, IL'
  },
  {
    id: 'user6',
    name: 'Robert Johnson',
    email: 'robert@example.com',
    role: 'freelancer',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
    skills: ['WordPress', 'PHP', 'Web Development', 'WooCommerce', 'Theme Development'],
    hourlyRate: 40,
    title: 'WordPress Developer',
    about: 'WordPress expert with extensive experience building custom themes and plugins. I create fast, responsive, and secure WordPress websites.',
    experience: 6,
    languages: ['English', 'French'],
    completedJobs: 55,
    rating: 4.6,
    joinedDate: format(subYears(new Date(), 2), 'yyyy-MM-dd'),
    location: 'Portland, OR'
  },
  {
    id: 'user7',
    name: 'Aisha Patel',
    email: 'aisha@example.com',
    role: 'freelancer',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
    skills: ['iOS Development', 'Swift', 'SwiftUI', 'Mobile App Development', 'UI Design'],
    hourlyRate: 60,
    title: 'iOS Developer',
    about: 'Dedicated mobile developer with a passion for creating beautiful and functional iOS applications. Apple Design Award nominee.',
    experience: 5,
    languages: ['English', 'Hindi'],
    completedJobs: 31,
    rating: 4.9,
    joinedDate: format(subYears(new Date(), 1), 'yyyy-MM-dd'),
    location: 'Boston, MA'
  }
];

// Mock Jobs
export const mockJobs: Job[] = [
  {
    id: 'job1',
    title: 'React Developer Needed for E-commerce Website',
    description: 'We are looking for an experienced React developer to build a modern e-commerce website. The ideal candidate should have experience with React, Redux, and integrating with RESTful APIs. Experience with payment gateways is a plus.',
    createdAt: format(subDays(new Date(), 2), 'yyyy-MM-dd'),
    updatedAt: format(subDays(new Date(), 2), 'yyyy-MM-dd'),
    clientId: 'user1',
    client: mockClients[0],
    budget: {
      min: 2000,
      max: 3000
    },
    skills: ['React', 'Redux', 'JavaScript', 'API Integration'],
    category: 'Web Development',
    experience: 'Intermediate',
    duration: '2-3 months',
    proposals: 7,
    status: 'open'
  },
  {
    id: 'job2',
    title: 'UI/UX Designer for Mobile App Redesign',
    description: 'Looking for a talented UI/UX designer to redesign our existing mobile app. The project involves creating a new modern interface, improving user flows, and designing a coherent design system. Proficiency in Figma is required.',
    createdAt: format(subDays(new Date(), 7), 'yyyy-MM-dd'),
    updatedAt: format(subDays(new Date(), 5), 'yyyy-MM-dd'),
    clientId: 'user3',
    client: mockClients[1],
    budget: {
      min: 1500,
      max: 2500
    },
    skills: ['UI/UX Design', 'Figma', 'Mobile Design', 'Prototyping'],
    category: 'Design',
    experience: 'Expert',
    duration: '1-2 months',
    proposals: 12,
    status: 'open'
  },
  {
    id: 'job3',
    title: 'Content Writer for Technology Blog',
    description: 'We need a skilled content writer to create engaging, informative articles for our technology blog. Topics will include software development, AI, and tech industry trends. SEO knowledge is essential.',
    createdAt: format(subDays(new Date(), 14), 'yyyy-MM-dd'),
    updatedAt: format(subDays(new Date(), 14), 'yyyy-MM-dd'),
    clientId: 'user1',
    client: mockClients[0],
    budget: {
      min: 500,
      max: 1000
    },
    skills: ['Content Writing', 'SEO', 'Technical Writing'],
    category: 'Writing',
    experience: 'Intermediate',
    duration: 'Ongoing',
    proposals: 18,
    status: 'open'
  },
  {
    id: 'job4',
    title: 'WordPress Website Development',
    description: 'Need an experienced WordPress developer to create a custom website for our real estate agency. The site should include property listings, agent profiles, search functionality, and integration with real estate APIs.',
    createdAt: format(subDays(new Date(), 10), 'yyyy-MM-dd'),
    updatedAt: format(subDays(new Date(), 8), 'yyyy-MM-dd'),
    clientId: 'user3',
    client: mockClients[1],
    budget: {
      min: 1000,
      max: 2000
    },
    skills: ['WordPress', 'PHP', 'CSS', 'JavaScript'],
    category: 'Web Development',
    experience: 'Intermediate',
    duration: '1 month',
    proposals: 9,
    status: 'open'
  },
  {
    id: 'job5',
    title: 'iOS App Development for Fitness Tracking',
    description: 'We are seeking an iOS developer to create a fitness tracking app. The app will track workouts, provide analytics, and integrate with Apple Health. Experience with SwiftUI and HealthKit is required.',
    createdAt: format(subDays(new Date(), 20), 'yyyy-MM-dd'),
    updatedAt: format(subDays(new Date(), 18), 'yyyy-MM-dd'),
    clientId: 'user1',
    client: mockClients[0],
    budget: {
      min: 4000,
      max: 6000
    },
    skills: ['iOS', 'Swift', 'SwiftUI', 'HealthKit'],
    category: 'Mobile Development',
    experience: 'Expert',
    duration: '3-4 months',
    proposals: 5,
    status: 'open'
  }
];

// Mock Proposals
export const mockProposals: Proposal[] = [
  {
    id: 'proposal1',
    jobId: 'job1',
    freelancerId: 'user2',
    coverLetter: 'I have extensive experience with React and have built several e-commerce platforms. I believe my skills are a perfect match for this project.',
    bidAmount: 2500,
    estimatedDuration: '2 months',
    status: 'pending',
    createdAt: format(subDays(new Date(), 1), 'yyyy-MM-dd')
  },
  {
    id: 'proposal2',
    jobId: 'job2',
    freelancerId: 'user4',
    coverLetter: 'As a UI/UX specialist with particular focus on mobile design, I can deliver a modern and intuitive interface for your app.',
    bidAmount: 2000,
    estimatedDuration: '6 weeks',
    status: 'pending',
    createdAt: format(subDays(new Date(), 5), 'yyyy-MM-dd')
  }
];

// Mock Reviews
export const mockReviews: Review[] = [
  {
    id: 'review1',
    jobId: 'completedJob1',
    clientId: 'user1',
    freelancerId: 'user2',
    rating: 5,
    comment: 'Sarah did an excellent job on our project. She delivered ahead of schedule and the code quality was outstanding.',
    createdAt: format(subDays(new Date(), 30), 'yyyy-MM-dd')
  },
  {
    id: 'review2',
    jobId: 'completedJob2',
    clientId: 'user3',
    freelancerId: 'user4',
    rating: 5,
    comment: 'Michael is an amazing designer. The UI he created for our app exceeded our expectations. Highly recommended!',
    createdAt: format(subDays(new Date(), 45), 'yyyy-MM-dd')
  }
];

// Mock Conversations
export const mockConversations: Conversation[] = [
  {
    id: 'conv1',
    participants: ['user1', 'user2'],
    unreadCount: 2
  },
  {
    id: 'conv2',
    participants: ['user3', 'user4'],
    unreadCount: 0
  }
];

// Mock Messages
export const mockMessages: Message[] = [
  {
    id: 'msg1',
    senderId: 'user1',
    receiverId: 'user2',
    content: 'Hi Sarah, I was impressed by your proposal. When can we schedule a call to discuss the project?',
    createdAt: format(subDays(new Date(), 3), 'yyyy-MM-dd\'T\'HH:mm:ss'),
    read: true
  },
  {
    id: 'msg2',
    senderId: 'user2',
    receiverId: 'user1',
    content: 'Hello John, thank you for considering my proposal. I\'m available tomorrow between 2-5pm EST for a call.',
    createdAt: format(subDays(new Date(), 2), 'yyyy-MM-dd\'T\'HH:mm:ss'),
    read: true
  },
  {
    id: 'msg3',
    senderId: 'user1',
    receiverId: 'user2',
    content: 'That works for me. Let\'s do 3pm EST. I\'ll send you a meeting link.',
    createdAt: format(subDays(new Date(), 2), 'yyyy-MM-dd\'T\'HH:mm:ss'),
    read: false
  },
  {
    id: 'msg4',
    senderId: 'user1',
    receiverId: 'user2',
    content: 'Here\'s the link for our call: [meeting link]',
    createdAt: format(subDays(new Date(), 1), 'yyyy-MM-dd\'T\'HH:mm:ss'),
    read: false
  }
];

// Get all users (clients and freelancers)
export const getAllUsers = () => {
  return [...mockClients, ...mockFreelancers];
};

// Get user by ID
export const getUserById = (userId: string) => {
  return getAllUsers().find(user => user.id === userId) || null;
};

// Get freelancer by ID
export const getFreelancerById = (id: string) => {
  return mockFreelancers.find(freelancer => freelancer.id === id) || null;
};

// Get client by ID
export const getClientById = (id: string) => {
  return mockClients.find(client => client.id === id) || null;
};

// Get all jobs
export const getAllJobs = () => {
  return mockJobs;
};

// Get job by ID
export const getJobById = (id: string) => {
  return mockJobs.find(job => job.id === id) || null;
};

// Get jobs by client ID
export const getJobsByClientId = (clientId: string) => {
  return mockJobs.filter(job => job.clientId === clientId);
};

// Get proposals by job ID
export const getProposalsByJobId = (jobId: string) => {
  return mockProposals.filter(proposal => proposal.jobId === jobId);
};

// Get proposals by freelancer ID
export const getProposalsByFreelancerId = (freelancerId: string) => {
  return mockProposals.filter(proposal => proposal.freelancerId === freelancerId);
};

// Get reviews by freelancer ID
export const getReviewsByFreelancerId = (freelancerId: string) => {
  return mockReviews.filter(review => review.freelancerId === freelancerId);
};

// Get conversations by user ID
export const getConversationsByUserId = (userId: string) => {
  return mockConversations.filter(conv => conv.participants.includes(userId));
};

// Get messages by conversation
export const getMessagesByConversation = (conversationId: string) => {
  // In a real app, we would look up the conversation participants
  // For this mock, we'll just return all messages between user1 and user2
  if (conversationId === 'conv1') {
    return mockMessages.filter(msg => 
      (msg.senderId === 'user1' && msg.receiverId === 'user2') ||
      (msg.senderId === 'user2' && msg.receiverId === 'user1')
    ).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }
  return [];
};