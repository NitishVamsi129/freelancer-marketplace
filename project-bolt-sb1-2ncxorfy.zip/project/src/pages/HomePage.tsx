import React from 'react';
import { Link } from 'react-router-dom';
import { Search, FileCheck, Medal, Shield, ArrowRight } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <div className="md:flex md:items-center md:justify-between">
            <div className="md:w-1/2">
              <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
                Find the perfect freelancer for your project
              </h1>
              <p className="text-lg md:text-xl mb-8 text-blue-100">
                Connect with talented professionals who can help bring your ideas to life.
                From web development to graphic design, we've got you covered.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link
                  to="/freelancers"
                  className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md bg-white text-blue-700 hover:bg-blue-50 transition-colors"
                >
                  Find Talent
                </Link>
                <Link
                  to="/signup"
                  className="inline-flex items-center justify-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-blue-700 transition-colors"
                >
                  Join as Freelancer
                </Link>
              </div>
            </div>
            <div className="mt-10 md:mt-0 md:w-5/12">
              <img 
                src="https://images.pexels.com/photos/3153198/pexels-photo-3153198.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                alt="Freelancers collaborating" 
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Search Categories */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Find experts in every category</h2>
          <p className="mt-4 text-lg text-gray-600">
            Browse our top categories and find the perfect match for your project needs
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          {[
            { name: 'Web Development', icon: '💻', count: '5,240+' },
            { name: 'Graphic Design', icon: '🎨', count: '3,120+' },
            { name: 'Digital Marketing', icon: '📱', count: '2,875+' },
            { name: 'Content Writing', icon: '✍️', count: '4,350+' },
            { name: 'UI/UX Design', icon: '🖌️', count: '1,960+' },
            { name: 'Video Editing', icon: '🎬', count: '1,450+' },
            { name: 'Data Science', icon: '📊', count: '980+' },
            { name: 'Mobile Development', icon: '📲', count: '2,240+' },
          ].map((category, index) => (
            <Link 
              key={index}
              to="/freelancers"
              className="flex flex-col items-center p-6 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
            >
              <span className="text-3xl mb-2">{category.icon}</span>
              <h3 className="text-lg font-medium text-gray-900">{category.name}</h3>
              <p className="text-sm text-gray-500">{category.count} experts</p>
            </Link>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Link
            to="/freelancers"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium"
          >
            View all categories
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>

      {/* How it Works */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">How FreelanceHub Works</h2>
            <p className="mt-4 text-lg text-gray-600">
              A simple, streamlined process to connect you with the right talent
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-sm text-center">
              <div className="bg-blue-100 h-16 w-16 flex items-center justify-center rounded-full mx-auto mb-4">
                <Search className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">1. Post a Job</h3>
              <p className="text-gray-600">
                Tell us what you need. Provide as many details as possible so freelancers can give you accurate proposals.
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-sm text-center">
              <div className="bg-blue-100 h-16 w-16 flex items-center justify-center rounded-full mx-auto mb-4">
                <FileCheck className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">2. Review Proposals</h3>
              <p className="text-gray-600">
                Receive proposals from interested freelancers. Compare their profiles, reviews, and portfolios.
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-sm text-center">
              <div className="bg-blue-100 h-16 w-16 flex items-center justify-center rounded-full mx-auto mb-4">
                <Medal className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">3. Hire & Collaborate</h3>
              <p className="text-gray-600">
                Select the best match for your project, communicate through our platform, and get work done.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">What Our Users Say</h2>
          <p className="mt-4 text-lg text-gray-600">
            Read testimonials from satisfied clients and freelancers
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center mb-4">
              <img
                src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150"
                alt="Client"
                className="h-12 w-12 rounded-full object-cover"
              />
              <div className="ml-4">
                <h4 className="text-lg font-semibold">Michael Thompson</h4>
                <p className="text-gray-600">CEO, TechStart</p>
              </div>
            </div>
            <p className="text-gray-700 italic">
              "I found an exceptional developer on FreelanceHub who helped us launch our product
              two weeks ahead of schedule. The quality of talent on this platform is outstanding!"
            </p>
            <div className="mt-4 flex text-yellow-400">
              {'★'.repeat(5)}
            </div>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center mb-4">
              <img
                src="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150"
                alt="Freelancer"
                className="h-12 w-12 rounded-full object-cover"
              />
              <div className="ml-4">
                <h4 className="text-lg font-semibold">Jessica Chen</h4>
                <p className="text-gray-600">UI/UX Designer</p>
              </div>
            </div>
            <p className="text-gray-700 italic">
              "As a freelancer, FreelanceHub has connected me with amazing clients and projects
              that align perfectly with my skills. I've been able to grow my business consistently."
            </p>
            <div className="mt-4 flex text-yellow-400">
              {'★'.repeat(5)}
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
          <p className="text-xl mb-8 text-blue-100">
            Join thousands of clients and freelancers who are already using FreelanceHub.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Link
              to="/signup"
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md bg-white text-blue-700 hover:bg-blue-50"
            >
              Create Account
            </Link>
            <Link
              to="/freelancers"
              className="inline-flex items-center justify-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-blue-700"
            >
              Browse Freelancers
            </Link>
          </div>
        </div>
      </div>

      {/* Trust Signals */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row items-center justify-center md:justify-between text-center md:text-left">
          <div className="mb-6 md:mb-0">
            <div className="flex items-center justify-center md:justify-start">
              <Shield className="h-6 w-6 text-blue-600 mr-2" />
              <span className="text-gray-700 font-medium">Secure Payments</span>
            </div>
          </div>
          <div className="mb-6 md:mb-0">
            <div className="flex items-center justify-center md:justify-start">
              <Shield className="h-6 w-6 text-blue-600 mr-2" />
              <span className="text-gray-700 font-medium">24/7 Support</span>
            </div>
          </div>
          <div>
            <div className="flex items-center justify-center md:justify-start">
              <Shield className="h-6 w-6 text-blue-600 mr-2" />
              <span className="text-gray-700 font-medium">Satisfaction Guarantee</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;