import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Star, MapPin, ChevronDown, ChevronUp } from 'lucide-react';
import { mockFreelancers } from '../data/mockData';
import { Freelancer } from '../models/types';

const FreelancerSearchPage: React.FC = () => {
  const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
  const [filteredFreelancers, setFilteredFreelancers] = useState<Freelancer[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [rateRange, setRateRange] = useState<[number, number]>([0, 100]);
  const [experienceLevel, setExperienceLevel] = useState<string>('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Load freelancers on mount
  useEffect(() => {
    setFreelancers(mockFreelancers);
    setFilteredFreelancers(mockFreelancers);
  }, []);

  // Filter freelancers whenever filters change
  useEffect(() => {
    let results = freelancers;
    
    // Filter by search term
    if (searchTerm) {
      results = results.filter(
        f => 
          f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          f.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
          f.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Filter by selected skills
    if (selectedSkills.length > 0) {
      results = results.filter(f => 
        selectedSkills.every(skill => f.skills.includes(skill))
      );
    }
    
    // Filter by rate range
    results = results.filter(f => 
      f.hourlyRate >= rateRange[0] && f.hourlyRate <= rateRange[1]
    );
    
    // Filter by experience level
    if (experienceLevel) {
      switch(experienceLevel) {
        case 'entry':
          results = results.filter(f => f.experience < 3);
          break;
        case 'intermediate':
          results = results.filter(f => f.experience >= 3 && f.experience < 6);
          break;
        case 'expert':
          results = results.filter(f => f.experience >= 6);
          break;
      }
    }
    
    setFilteredFreelancers(results);
  }, [freelancers, searchTerm, selectedSkills, rateRange, experienceLevel]);

  // Toggle skill selection
  const toggleSkill = (skill: string) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter(s => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  // Get all unique skills from freelancers
  const allSkills = Array.from(
    new Set(freelancers.flatMap(f => f.skills))
  ).sort();

  // Toggle mobile filters
  const toggleFilters = () => {
    setIsFilterOpen(!isFilterOpen);
  };

  return (
    <div className="bg-gray-50 min-h-screen pb-12">
      <div className="bg-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-4">Find the Perfect Freelancer</h1>
          <p className="text-blue-100 mb-8">Browse our talented freelancers and find the perfect match for your project</p>
          
          {/* Search Bar */}
          <div className="relative max-w-2xl">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-3 border border-transparent rounded-md leading-5 bg-white text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-transparent"
              placeholder="Search by skill, name, or title"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="md:flex">
          {/* Mobile filter toggle */}
          <div className="md:hidden mb-4">
            <button
              onClick={toggleFilters}
              className="flex items-center justify-between w-full px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <div className="flex items-center">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </div>
              {isFilterOpen ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
            </button>
          </div>
          
          {/* Filters - Desktop always visible, mobile toggleable */}
          <div className={`md:w-1/4 md:pr-8 ${isFilterOpen ? 'block' : 'hidden md:block'}`}>
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Filters</h3>
              
              {/* Hourly Rate Filter */}
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Hourly Rate</h4>
                <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                  <span>${rateRange[0]}</span>
                  <span>${rateRange[1]}+</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={rateRange[1]}
                  onChange={(e) => setRateRange([rateRange[0], parseInt(e.target.value)])}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
              </div>
              
              {/* Experience Level Filter */}
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Experience Level</h4>
                <div className="space-y-2">
                  {['entry', 'intermediate', 'expert'].map((level) => (
                    <div key={level} className="flex items-center">
                      <input
                        id={`experience-${level}`}
                        name="experience"
                        type="radio"
                        checked={experienceLevel === level}
                        onChange={() => setExperienceLevel(level)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor={`experience-${level}`} className="ml-3 text-sm text-gray-700 capitalize">
                        {level}
                      </label>
                    </div>
                  ))}
                  {experienceLevel && (
                    <button
                      onClick={() => setExperienceLevel('')}
                      className="text-sm text-blue-600 hover:text-blue-800"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
              
              {/* Skills Filter */}
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Skills</h4>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {allSkills.map((skill) => (
                    <div key={skill} className="flex items-center">
                      <input
                        id={`skill-${skill}`}
                        type="checkbox"
                        checked={selectedSkills.includes(skill)}
                        onChange={() => toggleSkill(skill)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor={`skill-${skill}`} className="ml-3 text-sm text-gray-700">
                        {skill}
                      </label>
                    </div>
                  ))}
                </div>
                {selectedSkills.length > 0 && (
                  <button
                    onClick={() => setSelectedSkills([])}
                    className="mt-3 text-sm text-blue-600 hover:text-blue-800"
                  >
                    Clear all
                  </button>
                )}
              </div>
            </div>
          </div>
          
          {/* Freelancer List */}
          <div className="md:w-3/4">
            <div className="mb-6 flex items-center justify-between">
              <p className="text-gray-700">
                Showing <span className="font-medium">{filteredFreelancers.length}</span> freelancers
              </p>
              <div className="flex items-center">
                <span className="mr-2 text-sm text-gray-700">Sort by:</span>
                <select className="border border-gray-300 rounded-md text-sm py-1 px-2 bg-white">
                  <option>Relevance</option>
                  <option>Hourly Rate: Low to High</option>
                  <option>Hourly Rate: High to Low</option>
                  <option>Rating</option>
                </select>
              </div>
            </div>
            
            {filteredFreelancers.length === 0 ? (
              <div className="bg-white rounded-lg shadow p-8 text-center">
                <h3 className="text-lg font-medium text-gray-900 mb-2">No freelancers found</h3>
                <p className="text-gray-600 mb-4">Try adjusting your filters or search criteria</p>
                <button
                  onClick={() => {
                    setSearchTerm('');
                    setSelectedSkills([]);
                    setRateRange([0, 100]);
                    setExperienceLevel('');
                  }}
                  className="text-blue-600 hover:text-blue-800 font-medium"
                >
                  Clear all filters
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {filteredFreelancers.map((freelancer) => (
                  <div key={freelancer.id} className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow">
                    <div className="flex flex-col md:flex-row">
                      <div className="md:w-1/6 flex justify-center mb-4 md:mb-0">
                        {freelancer.avatar ? (
                          <img 
                            src={freelancer.avatar} 
                            alt={freelancer.name} 
                            className="h-20 w-20 rounded-full object-cover"
                          />
                        ) : (
                          <div className="h-20 w-20 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-xl font-semibold">
                            {freelancer.name.charAt(0)}
                          </div>
                        )}
                      </div>
                      <div className="md:w-3/4 md:pl-4">
                        <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                          <Link to={`/freelancers/${freelancer.id}`} className="text-xl font-semibold text-gray-900 hover:text-blue-600">
                            {freelancer.name}
                          </Link>
                          <div className="flex items-center mt-2 md:mt-0">
                            <Star className="h-4 w-4 text-yellow-400 fill-current" />
                            <span className="ml-1 text-gray-800 font-medium">{freelancer.rating}</span>
                            <span className="ml-1 text-gray-600">({freelancer.completedJobs} jobs)</span>
                          </div>
                        </div>
                        <p className="text-gray-800 font-medium mb-2">{freelancer.title}</p>
                        <div className="flex items-center text-gray-600 text-sm mb-4">
                          <MapPin className="h-4 w-4 mr-1" />
                          {freelancer.location}
                        </div>
                        <p className="text-gray-700 text-sm line-clamp-2 mb-4">
                          {freelancer.about}
                        </p>
                        <div className="flex flex-wrap gap-2 mb-2">
                          {freelancer.skills.slice(0, 5).map((skill, idx) => (
                            <span key={idx} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                              {skill}
                            </span>
                          ))}
                          {freelancer.skills.length > 5 && (
                            <span className="text-gray-500 text-xs px-2 py-1">
                              +{freelancer.skills.length - 5} more
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="md:w-1/6 flex flex-col items-center justify-center mt-4 md:mt-0 border-t pt-4 md:pt-0 md:border-t-0 md:border-l md:pl-4">
                        <p className="text-gray-800 font-bold text-xl mb-2">${freelancer.hourlyRate}/hr</p>
                        <Link
                          to={`/freelancers/${freelancer.id}`}
                          className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 text-center"
                        >
                          View Profile
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FreelancerSearchPage;