import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, Info } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const JobPostPage: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [skillsInput, setSkillsInput] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [experienceLevel, setExperienceLevel] = useState('');
  const [budget, setBudget] = useState<{min: string, max: string}>({min: '', max: ''});
  const [duration, setDuration] = useState('');
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Categories for dropdown
  const categories = [
    'Web Development',
    'Mobile Development',
    'UI/UX Design',
    'Graphic Design',
    'Content Writing',
    'SEO',
    'Digital Marketing',
    'Data Science',
    'Video Editing',
    'Other'
  ];
  
  // Experience levels
  const experienceLevels = ['Entry', 'Intermediate', 'Expert'];
  
  // Duration options
  const durationOptions = [
    'Less than 1 month',
    '1-3 months',
    '3-6 months',
    '6+ months',
    'Ongoing'
  ];
  
  // Add a skill
  const addSkill = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && skillsInput.trim()) {
      e.preventDefault();
      if (!skills.includes(skillsInput.trim())) {
        setSkills([...skills, skillsInput.trim()]);
      }
      setSkillsInput('');
    }
  };
  
  // Remove a skill
  const removeSkill = (skillToRemove: string) => {
    setSkills(skills.filter(skill => skill !== skillToRemove));
  };
  
  // Validate form
  const validateForm = () => {
    const newErrors: {[key: string]: string} = {};
    
    if (!title.trim()) newErrors.title = 'Title is required';
    if (!description.trim()) newErrors.description = 'Description is required';
    if (!category) newErrors.category = 'Please select a category';
    if (skills.length === 0) newErrors.skills = 'At least one skill is required';
    if (!experienceLevel) newErrors.experienceLevel = 'Please select experience level';
    if (!budget.min) newErrors.budgetMin = 'Minimum budget is required';
    if (!budget.max) newErrors.budgetMax = 'Maximum budget is required';
    if (Number(budget.min) > Number(budget.max)) newErrors.budget = 'Min budget cannot be greater than max budget';
    if (!duration) newErrors.duration = 'Please select project duration';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate posting a job
    setTimeout(() => {
      setIsSubmitting(false);
      
      // In a real app, you would send this data to your API
      // For demo purposes, we'll just navigate to the dashboard
      navigate('/client-dashboard');
    }, 1500);
  };
  
  return (
    <div className="bg-gray-50 min-h-screen pb-12">
      <div className="bg-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-4">Post a Job</h1>
          <p className="text-blue-100">
            Find the perfect freelancer for your project by creating a detailed job posting
          </p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <form onSubmit={handleSubmit}>
            {/* Job Title */}
            <div className="mb-6">
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Job Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className={`block w-full px-3 py-2 border ${
                  errors.title ? 'border-red-300' : 'border-gray-300'
                } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                placeholder="e.g., WordPress Developer for E-commerce Website"
              />
              {errors.title && (
                <p className="mt-1 text-sm text-red-600">{errors.title}</p>
              )}
            </div>
            
            {/* Job Description */}
            <div className="mb-6">
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Job Description <span className="text-red-500">*</span>
              </label>
              <textarea
                id="description"
                rows={6}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className={`block w-full px-3 py-2 border ${
                  errors.description ? 'border-red-300' : 'border-gray-300'
                } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                placeholder="Describe your project in detail. Include specific requirements, deliverables, and any other relevant information."
              ></textarea>
              {errors.description && (
                <p className="mt-1 text-sm text-red-600">{errors.description}</p>
              )}
              <p className="mt-1 text-sm text-gray-500">
                Tip: Be clear and specific about your requirements to attract qualified freelancers.
              </p>
            </div>
            
            {/* Category */}
            <div className="mb-6">
              <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                Category <span className="text-red-500">*</span>
              </label>
              <select
                id="category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className={`block w-full px-3 py-2 border ${
                  errors.category ? 'border-red-300' : 'border-gray-300'
                } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
              >
                <option value="">Select a category</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              {errors.category && (
                <p className="mt-1 text-sm text-red-600">{errors.category}</p>
              )}
            </div>
            
            {/* Skills */}
            <div className="mb-6">
              <label htmlFor="skills" className="block text-sm font-medium text-gray-700 mb-1">
                Skills Required <span className="text-red-500">*</span>
              </label>
              <div className={`flex flex-wrap items-center border ${
                errors.skills ? 'border-red-300' : 'border-gray-300'
              } rounded-md focus-within:ring-1 focus-within:ring-blue-500 focus-within:border-blue-500`}>
                {skills.map((skill) => (
                  <div
                    key={skill}
                    className="flex items-center bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded m-1"
                  >
                    {skill}
                    <button
                      type="button"
                      onClick={() => removeSkill(skill)}
                      className="ml-1 text-blue-600 hover:text-blue-800 focus:outline-none"
                    >
                      &times;
                    </button>
                  </div>
                ))}
                <input
                  type="text"
                  id="skills"
                  value={skillsInput}
                  onChange={(e) => setSkillsInput(e.target.value)}
                  onKeyDown={addSkill}
                  className="flex-grow px-3 py-2 focus:outline-none text-sm"
                  placeholder="Type a skill and press Enter"
                />
              </div>
              {errors.skills && (
                <p className="mt-1 text-sm text-red-600">{errors.skills}</p>
              )}
              <p className="mt-1 text-sm text-gray-500">
                Tip: Add skills that are specific to your project.
              </p>
            </div>
            
            {/* Experience Level */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Experience Level <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {experienceLevels.map((level) => (
                  <div key={level} className="relative">
                    <input
                      type="radio"
                      id={`experience-${level}`}
                      name="experienceLevel"
                      value={level}
                      checked={experienceLevel === level}
                      onChange={() => setExperienceLevel(level)}
                      className="sr-only"
                    />
                    <label
                      htmlFor={`experience-${level}`}
                      className={`block w-full p-3 border rounded-md text-center cursor-pointer ${
                        experienceLevel === level
                          ? 'bg-blue-50 border-blue-500 text-blue-700'
                          : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {level}
                    </label>
                  </div>
                ))}
              </div>
              {errors.experienceLevel && (
                <p className="mt-1 text-sm text-red-600">{errors.experienceLevel}</p>
              )}
            </div>
            
            {/* Budget */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Budget (USD) <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <input
                    type="number"
                    min="0"
                    placeholder="Min"
                    value={budget.min}
                    onChange={(e) => setBudget({ ...budget, min: e.target.value })}
                    className={`block w-full px-3 py-2 border ${
                      errors.budgetMin || errors.budget ? 'border-red-300' : 'border-gray-300'
                    } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                  />
                </div>
                <div>
                  <input
                    type="number"
                    min="0"
                    placeholder="Max"
                    value={budget.max}
                    onChange={(e) => setBudget({ ...budget, max: e.target.value })}
                    className={`block w-full px-3 py-2 border ${
                      errors.budgetMax || errors.budget ? 'border-red-300' : 'border-gray-300'
                    } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                  />
                </div>
              </div>
              {(errors.budgetMin || errors.budgetMax || errors.budget) && (
                <p className="mt-1 text-sm text-red-600">
                  {errors.budget || errors.budgetMin || errors.budgetMax}
                </p>
              )}
            </div>
            
            {/* Duration */}
            <div className="mb-6">
              <label htmlFor="duration" className="block text-sm font-medium text-gray-700 mb-1">
                Project Duration <span className="text-red-500">*</span>
              </label>
              <select
                id="duration"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className={`block w-full px-3 py-2 border ${
                  errors.duration ? 'border-red-300' : 'border-gray-300'
                } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
              >
                <option value="">Select project duration</option>
                {durationOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              {errors.duration && (
                <p className="mt-1 text-sm text-red-600">{errors.duration}</p>
              )}
            </div>
            
            {/* Submit */}
            <div className="mt-8">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300"
              >
                {isSubmitting ? 'Posting Job...' : 'Post Job'}
              </button>
            </div>
          </form>
        </div>
        
        {/* Tips Section */}
        <div className="mt-8 bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Tips for a Successful Job Post</h2>
          <div className="space-y-4">
            <div className="flex">
              <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-700">Be specific about your requirements and deliverables</p>
            </div>
            <div className="flex">
              <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-700">Include relevant skills to attract qualified freelancers</p>
            </div>
            <div className="flex">
              <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-700">Set a realistic budget range for your project</p>
            </div>
            <div className="flex">
              <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-700">Provide clear context about your project's goals</p>
            </div>
            <div className="flex">
              <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-700">Respond promptly to questions and proposals</p>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-blue-50 rounded-md flex items-start">
            <Info className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-blue-700">
              Need help with your job post? Our <a href="#" className="underline">Job Post Guide</a> provides
              detailed information on creating effective job listings.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobPostPage;