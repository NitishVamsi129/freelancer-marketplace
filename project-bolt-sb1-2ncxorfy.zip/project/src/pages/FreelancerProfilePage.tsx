import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, MapPin, Languages, Star, Briefcase, BookOpen, Clock, ExternalLink, MessageSquare } from 'lucide-react';
import { format } from 'date-fns';
import { getFreelancerById, getReviewsByFreelancerId } from '../data/mockData';
import { Freelancer, Review } from '../models/types';
import { useAuth } from '../contexts/AuthContext';

const FreelancerProfilePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [freelancer, setFreelancer] = useState<Freelancer | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'portfolio' | 'reviews'>('overview');
  const { currentUser, isAuthenticated } = useAuth();

  useEffect(() => {
    if (id) {
      const fetchedFreelancer = getFreelancerById(id);
      setFreelancer(fetchedFreelancer);
      
      const fetchedReviews = getReviewsByFreelancerId(id);
      setReviews(fetchedReviews);
    }
  }, [id]);

  if (!freelancer) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen pb-12">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex items-center">
              {freelancer.avatar ? (
                <img
                  src={freelancer.avatar}
                  alt={freelancer.name}
                  className="h-20 w-20 rounded-full object-cover mr-6"
                />
              ) : (
                <div className="h-20 w-20 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-xl font-semibold mr-6">
                  {freelancer.name.charAt(0)}
                </div>
              )}
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{freelancer.name}</h1>
                <p className="text-lg text-gray-700 mt-1">{freelancer.title}</p>
                <div className="flex items-center mt-2 text-gray-600">
                  <MapPin className="h-5 w-5 mr-1" />
                  <span>{freelancer.location}</span>
                </div>
              </div>
            </div>
            <div className="mt-6 md:mt-0 flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-4">
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-400 fill-current" />
                <span className="ml-1 text-gray-800 font-medium">{freelancer.rating}</span>
                <span className="ml-1 text-gray-600">({freelancer.completedJobs} jobs)</span>
              </div>
              <p className="font-bold text-xl text-gray-800">${freelancer.hourlyRate}/hr</p>
              {isAuthenticated && currentUser?.role === 'client' && (
                <Link
                  to="/messages"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Contact
                </Link>
              )}
            </div>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="border-t border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <nav className="flex -mb-px">
              <button
                onClick={() => setActiveTab('overview')}
                className={`py-4 px-1 border-b-2 font-medium text-sm mr-8 focus:outline-none ${
                  activeTab === 'overview'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Overview
              </button>
              {freelancer.portfolio && freelancer.portfolio.length > 0 && (
                <button
                  onClick={() => setActiveTab('portfolio')}
                  className={`py-4 px-1 border-b-2 font-medium text-sm mr-8 focus:outline-none ${
                    activeTab === 'portfolio'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  Portfolio
                </button>
              )}
              <button
                onClick={() => setActiveTab('reviews')}
                className={`py-4 px-1 border-b-2 font-medium text-sm focus:outline-none ${
                  activeTab === 'reviews'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Reviews
              </button>
            </nav>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:flex md:space-x-8">
          {/* Main Content */}
          <div className="md:w-2/3">
            {activeTab === 'overview' && (
              <div>
                <div className="bg-white rounded-lg shadow p-6 mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">About Me</h2>
                  <p className="text-gray-700">{freelancer.about}</p>
                </div>
                
                {freelancer.workHistory && freelancer.workHistory.length > 0 && (
                  <div className="bg-white rounded-lg shadow p-6 mb-6">
                    <h2 className="text-xl font-semibold text-gray-900 mb-4">Work History</h2>
                    <div className="space-y-6">
                      {freelancer.workHistory.map((work) => (
                        <div key={work.id} className="border-b border-gray-200 pb-6 last:border-b-0 last:pb-0">
                          <div className="flex justify-between">
                            <h3 className="text-lg font-medium text-gray-900">{work.title}</h3>
                            <div className="flex items-center text-gray-600 text-sm">
                              <Clock className="h-4 w-4 mr-1" />
                              <span>
                                {work.startDate.substring(0, 4)} - {work.current ? 'Present' : work.endDate?.substring(0, 4)}
                              </span>
                            </div>
                          </div>
                          <p className="text-gray-700 mt-1">{work.company}</p>
                          <p className="text-gray-600 mt-2">{work.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {freelancer.education && freelancer.education.length > 0 && (
                  <div className="bg-white rounded-lg shadow p-6 mb-6">
                    <h2 className="text-xl font-semibold text-gray-900 mb-4">Education</h2>
                    <div className="space-y-6">
                      {freelancer.education.map((edu) => (
                        <div key={edu.id} className="border-b border-gray-200 pb-6 last:border-b-0 last:pb-0">
                          <div className="flex justify-between">
                            <h3 className="text-lg font-medium text-gray-900">{edu.institution}</h3>
                            <div className="flex items-center text-gray-600 text-sm">
                              <Calendar className="h-4 w-4 mr-1" />
                              <span>
                                {edu.startDate.substring(0, 4)} - {edu.current ? 'Present' : edu.endDate?.substring(0, 4)}
                              </span>
                            </div>
                          </div>
                          <p className="text-gray-700 mt-1">{edu.degree}, {edu.fieldOfStudy}</p>
                          {edu.description && <p className="text-gray-600 mt-2">{edu.description}</p>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
            
            {activeTab === 'portfolio' && freelancer.portfolio && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Portfolio</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {freelancer.portfolio.map((item) => (
                    <div key={item.id} className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="p-4">
                        <h3 className="text-lg font-medium text-gray-900 mb-1">{item.title}</h3>
                        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{item.description}</p>
                        <div className="flex flex-wrap gap-2 mb-4">
                          {item.tags.map((tag, idx) => (
                            <span key={idx} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                              {tag}
                            </span>
                          ))}
                        </div>
                        {item.link && (
                          <a
                            href={item.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
                          >
                            View Project <ExternalLink className="h-3 w-3 ml-1" />
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {activeTab === 'reviews' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Client Reviews</h2>
                {reviews.length === 0 ? (
                  <p className="text-gray-600">No reviews yet.</p>
                ) : (
                  <div className="space-y-6">
                    {reviews.map((review) => (
                      <div key={review.id} className="border-b border-gray-200 pb-6 last:border-b-0 last:pb-0">
                        <div className="flex justify-between mb-2">
                          <div className="flex items-center">
                            <div className="flex text-yellow-400">
                              {Array.from({ length: 5 }).map((_, idx) => (
                                <Star
                                  key={idx}
                                  className={`h-5 w-5 ${idx < review.rating ? 'fill-current' : ''}`}
                                />
                              ))}
                            </div>
                            <span className="ml-2 text-gray-600">
                              {format(new Date(review.createdAt), 'MMM dd, yyyy')}
                            </span>
                          </div>
                        </div>
                        <p className="text-gray-700">{review.comment}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
          
          {/* Sidebar */}
          <div className="md:w-1/3 mt-6 md:mt-0">
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {freelancer.skills.map((skill, idx) => (
                  <span key={idx} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6 space-y-4">
              <div className="flex items-start">
                <Briefcase className="h-5 w-5 text-gray-500 mt-0.5 mr-3" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">Experience</h4>
                  <p className="text-gray-700">{freelancer.experience} years</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Languages className="h-5 w-5 text-gray-500 mt-0.5 mr-3" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">Languages</h4>
                  <p className="text-gray-700">{freelancer.languages.join(', ')}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <BookOpen className="h-5 w-5 text-gray-500 mt-0.5 mr-3" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">Member Since</h4>
                  <p className="text-gray-700">{format(new Date(freelancer.joinedDate), 'MMMM yyyy')}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Briefcase className="h-5 w-5 text-gray-500 mt-0.5 mr-3" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">Completed Jobs</h4>
                  <p className="text-gray-700">{freelancer.completedJobs}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FreelancerProfilePage;