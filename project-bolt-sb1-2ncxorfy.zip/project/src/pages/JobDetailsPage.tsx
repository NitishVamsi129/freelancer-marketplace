import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Clock, DollarSign, Briefcase, Users, Star, FileText, Send, MessageSquare } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { getJobById, getClientById } from '../data/mockData';
import { Job } from '../models/types';

const JobDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [job, setJob] = useState<Job | null>(null);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [bidAmount, setBidAmount] = useState('');
  const [estimatedDuration, setEstimatedDuration] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { currentUser, isAuthenticated } = useAuth();
  
  useEffect(() => {
    if (id) {
      const fetchedJob = getJobById(id);
      setJob(fetchedJob);
    }
  }, [id]);
  
  if (!job) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate submitting a proposal
    setTimeout(() => {
      setIsSubmitting(false);
      setIsApplyModalOpen(false);
      
      // Show success message
      alert('Your proposal has been submitted successfully!');
    }, 1500);
  };
  
  return (
    <div className="bg-gray-50 min-h-screen pb-12">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-2">{job.title}</h1>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              <div className="flex items-center">
                <Briefcase className="h-4 w-4 mr-1" />
                {job.category}
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                Posted {job.createdAt}
              </div>
              <div className="flex items-center">
                <Users className="h-4 w-4 mr-1" />
                {job.proposals} proposals
              </div>
              <div className="flex items-center">
                <DollarSign className="h-4 w-4 mr-1" />
                ${job.budget.min} - ${job.budget.max}
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {job.skills.map((skill, idx) => (
              <span key={idx} className="bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full">
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:flex md:space-x-8">
          {/* Main Content */}
          <div className="md:w-2/3">
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Job Description</h2>
              <p className="text-gray-700 whitespace-pre-line">{job.description}</p>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Requirements</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-md font-medium text-gray-900 mb-2">Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {job.skills.map((skill, idx) => (
                      <span key={idx} className="bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-md font-medium text-gray-900 mb-2">Experience Level</h3>
                  <p className="text-gray-700">{job.experience}</p>
                </div>
                
                <div>
                  <h3 className="text-md font-medium text-gray-900 mb-2">Project Duration</h3>
                  <p className="text-gray-700">{job.duration}</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="md:w-1/3 mt-6 md:mt-0">
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <div className="flex justify-between mb-6">
                <h3 className="text-lg font-medium text-gray-900">About the Client</h3>
                <div className="flex items-center text-yellow-400">
                  <Star className="h-4 w-4 fill-current" />
                  <span className="ml-1 text-gray-900 text-sm">4.9</span>
                </div>
              </div>
              
              <div className="flex items-center mb-4">
                <img
                  src={job.client.avatar}
                  alt={job.client.name}
                  className="h-12 w-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">{job.client.name}</h4>
                  {job.client.company && (
                    <p className="text-sm text-gray-600">{job.client.company}</p>
                  )}
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-4 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Location:</span>
                  <span className="text-gray-900">{job.client.location}</span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Member since:</span>
                  <span className="text-gray-900">{job.client.joinedDate}</span>
                </div>
                
                {job.client.totalSpent !== undefined && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Total spent:</span>
                    <span className="text-gray-900">${job.client.totalSpent}</span>
                  </div>
                )}
                
                {job.client.postedJobs !== undefined && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Jobs posted:</span>
                    <span className="text-gray-900">{job.client.postedJobs}</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <div className="mb-4">
                <h3 className="text-lg font-medium text-gray-900 mb-1">Budget</h3>
                <p className="text-2xl font-bold text-gray-900">${job.budget.min} - ${job.budget.max}</p>
              </div>
              
              {isAuthenticated && currentUser?.role === 'freelancer' ? (
                <button
                  onClick={() => setIsApplyModalOpen(true)}
                  className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Submit a Proposal
                </button>
              ) : isAuthenticated && currentUser?.role === 'client' ? (
                <p className="text-gray-600 text-sm">
                  You're currently signed in as a client and cannot apply to jobs. Please switch to a freelancer account to submit proposals.
                </p>
              ) : (
                <div>
                  <Link
                    to="/login"
                    className="block w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 text-center mb-2"
                  >
                    Login to Apply
                  </Link>
                  <Link
                    to="/signup"
                    className="block w-full py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 text-center"
                  >
                    Sign Up
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Apply Modal */}
      {isApplyModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-90vh overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold text-gray-900">Submit a Proposal</h3>
                <button
                  onClick={() => setIsApplyModalOpen(false)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  &times;
                </button>
              </div>
            </div>
            
            <form onSubmit={handleApply} className="p-6">
              <div className="mb-6">
                <label htmlFor="bid-amount" className="block text-sm font-medium text-gray-700 mb-1">
                  Bid Amount (USD) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-gray-500 sm:text-sm">$</span>
                  </div>
                  <input
                    type="number"
                    id="bid-amount"
                    min={job.budget.min}
                    max={job.budget.max}
                    required
                    value={bidAmount}
                    onChange={(e) => setBidAmount(e.target.value)}
                    className="block w-full pl-8 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    placeholder="Enter your bid amount"
                  />
                </div>
                <p className="mt-1 text-sm text-gray-500">
                  Client's budget: ${job.budget.min} - ${job.budget.max}
                </p>
              </div>
              
              <div className="mb-6">
                <label htmlFor="estimated-duration" className="block text-sm font-medium text-gray-700 mb-1">
                  Estimated Duration <span className="text-red-500">*</span>
                </label>
                <select
                  id="estimated-duration"
                  required
                  value={estimatedDuration}
                  onChange={(e) => setEstimatedDuration(e.target.value)}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                >
                  <option value="">Select duration</option>
                  <option value="Less than 1 week">Less than 1 week</option>
                  <option value="1-2 weeks">1-2 weeks</option>
                  <option value="2-4 weeks">2-4 weeks</option>
                  <option value="1-2 months">1-2 months</option>
                  <option value="2-3 months">2-3 months</option>
                  <option value="3+ months">3+ months</option>
                </select>
              </div>
              
              <div className="mb-6">
                <label htmlFor="cover-letter" className="block text-sm font-medium text-gray-700 mb-1">
                  Cover Letter <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="cover-letter"
                  rows={8}
                  required
                  value={coverLetter}
                  onChange={(e) => setCoverLetter(e.target.value)}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Introduce yourself, explain why you're a good fit for this job, and describe your relevant experience and approach."
                ></textarea>
                <p className="mt-1 text-sm text-gray-500">
                  Tip: Personalize your proposal to stand out from other freelancers.
                </p>
              </div>
              
              <div className="flex justify-end space-x-4">
                <button
                  type="button"
                  onClick={() => setIsApplyModalOpen(false)}
                  className="py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Proposal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobDetailsPage;