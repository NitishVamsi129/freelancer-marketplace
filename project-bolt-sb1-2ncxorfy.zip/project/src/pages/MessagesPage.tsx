import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { Send, Search, Phone, Video, MoreHorizontal } from 'lucide-react';
import { getConversationsByUserId, getMessagesByConversation, getUserById, mockMessages } from '../data/mockData';
import { Conversation, Message, User } from '../models/types';

const MessagesPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [otherUser, setOtherUser] = useState<User | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Load conversations on mount
  useEffect(() => {
    if (currentUser) {
      const userConversations = getConversationsByUserId(currentUser.id);
      setConversations(userConversations);
      
      // Set active conversation if there are any
      if (userConversations.length > 0) {
        setActiveConversation(userConversations[0].id);
      }
    }
  }, [currentUser]);
  
  // Load messages when active conversation changes
  useEffect(() => {
    if (activeConversation) {
      const conversationMessages = getMessagesByConversation(activeConversation);
      setMessages(conversationMessages);
      
      // Find the other user in the conversation
      const conversation = conversations.find(c => c.id === activeConversation);
      if (conversation && currentUser) {
        const otherUserId = conversation.participants.find(id => id !== currentUser.id);
        if (otherUserId) {
          const user = getUserById(otherUserId);
          setOtherUser(user);
        }
      }
    }
  }, [activeConversation, conversations, currentUser]);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !currentUser || !otherUser) return;
    
    // Create a new message
    const message: Message = {
      id: `msg${Date.now()}`,
      senderId: currentUser.id,
      receiverId: otherUser.id,
      content: newMessage,
      createdAt: new Date().toISOString(),
      read: false
    };
    
    // Add to messages
    setMessages([...messages, message]);
    setNewMessage('');
  };
  
  if (!currentUser) return null;
  
  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Messages</h1>
        
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="flex h-[calc(100vh-12rem)]">
            {/* Conversations List */}
            <div className="w-1/3 border-r border-gray-200">
              <div className="p-4 border-b border-gray-200">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    placeholder="Search messages"
                  />
                </div>
              </div>
              
              <div className="overflow-y-auto h-full pb-4">
                {conversations.length === 0 ? (
                  <div className="p-4 text-center text-gray-500">
                    No conversations yet
                  </div>
                ) : (
                  <ul className="divide-y divide-gray-200">
                    {conversations.map((conversation) => {
                      // Get the other user's ID
                      const otherUserId = conversation.participants.find(id => id !== currentUser.id);
                      const user = otherUserId ? getUserById(otherUserId) : null;
                      
                      // Find the last message for this conversation
                      const lastMessage = mockMessages.find(msg => 
                        (msg.senderId === currentUser.id && msg.receiverId === otherUserId) ||
                        (msg.senderId === otherUserId && msg.receiverId === currentUser.id)
                      );
                      
                      return (
                        <li key={conversation.id}>
                          <button
                            onClick={() => setActiveConversation(conversation.id)}
                            className={`block w-full px-4 py-3 hover:bg-gray-50 ${
                              activeConversation === conversation.id ? 'bg-blue-50' : ''
                            }`}
                          >
                            <div className="flex items-center">
                              {user?.avatar ? (
                                <img
                                  src={user.avatar}
                                  alt={user.name}
                                  className="h-10 w-10 rounded-full object-cover"
                                />
                              ) : (
                                <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-sm font-semibold">
                                  {user?.name.charAt(0)}
                                </div>
                              )}
                              <div className="ml-3 flex-1 text-left">
                                <p className="text-sm font-medium text-gray-900">{user?.name}</p>
                                {lastMessage && (
                                  <p className="text-xs text-gray-500 truncate">
                                    {lastMessage.content.substring(0, 30)}
                                    {lastMessage.content.length > 30 ? '...' : ''}
                                  </p>
                                )}
                              </div>
                              {conversation.unreadCount > 0 && (
                                <span className="ml-2 bg-blue-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                  {conversation.unreadCount}
                                </span>
                              )}
                            </div>
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            </div>
            
            {/* Messages */}
            <div className="w-2/3 flex flex-col">
              {activeConversation && otherUser ? (
                <>
                  {/* Chat Header */}
                  <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                    <div className="flex items-center">
                      {otherUser.avatar ? (
                        <img
                          src={otherUser.avatar}
                          alt={otherUser.name}
                          className="h-10 w-10 rounded-full object-cover"
                        />
                      ) : (
                        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-sm font-semibold">
                          {otherUser.name.charAt(0)}
                        </div>
                      )}
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">{otherUser.name}</p>
                        <p className="text-xs text-gray-500">{otherUser.role === 'client' ? 'Client' : 'Freelancer'}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button className="p-2 rounded-full hover:bg-gray-100 text-gray-500">
                        <Phone className="h-5 w-5" />
                      </button>
                      <button className="p-2 rounded-full hover:bg-gray-100 text-gray-500">
                        <Video className="h-5 w-5" />
                      </button>
                      <button className="p-2 rounded-full hover:bg-gray-100 text-gray-500">
                        <MoreHorizontal className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                  
                  {/* Messages */}
                  <div className="flex-1 p-4 overflow-y-auto">
                    <div className="space-y-4">
                      {messages.map((message) => {
                        const isMe = message.senderId === currentUser.id;
                        const messageDate = new Date(message.createdAt);
                        
                        return (
                          <div
                            key={message.id}
                            className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                          >
                            <div className="flex flex-col max-w-[70%]">
                              <div
                                className={`rounded-lg px-4 py-2 ${
                                  isMe
                                    ? 'bg-blue-600 text-white'
                                    : 'bg-gray-100 text-gray-800'
                                }`}
                              >
                                <p className="text-sm">{message.content}</p>
                              </div>
                              <span className="text-xs text-gray-500 mt-1">
                                {format(messageDate, 'MMM d, h:mm a')}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </div>
                  </div>
                  
                  {/* Message Input */}
                  <div className="p-4 border-t border-gray-200">
                    <form onSubmit={handleSendMessage} className="flex items-center">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Type a message..."
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 bg-blue-600 text-white rounded-r-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      >
                        <Send className="h-5 w-5" />
                      </button>
                    </form>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center text-gray-500">
                  Select a conversation to start messaging
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessagesPage;